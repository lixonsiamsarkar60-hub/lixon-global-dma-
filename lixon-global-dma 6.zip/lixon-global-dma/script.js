/* ==========================================================
   Lixon Global DMA - script.js
   Does three small jobs:
   1. Opens and closes the mobile menu.
   2. Highlights the current page in the menu and sets the
      footer year.
   3. Checks forms and (only if you connect a service) sends them.
   ========================================================== */

/* ----------------------------------------------------------
   FORM SETUP - the ONLY line you need to edit for forms.
   Leave it empty ("") until you have created a free form
   service account (see Stage 6 of the guide). Then paste the
   web address the service gives you, for example:
   "https://formspree.io/f/abcdwxyz"
   While it is empty, forms check the fields but DO NOT send
   anything, and the site says so honestly.
   Never paste passwords or private keys here: anything in this
   file is public.
   ---------------------------------------------------------- */
const FORM_ENDPOINT = "";

const GENERAL_EMAIL = "lixonglobaldma@gmail.com";

/* ---------- 1. Mobile menu ---------- */
(function () {
  const toggle = document.querySelector(".nav-toggle");
  const list = document.getElementById("nav-list");
  if (!toggle || !list) return;

  function setOpen(open) {
    list.classList.toggle("is-open", open);
    toggle.setAttribute("aria-expanded", String(open));
    toggle.textContent = open ? "Close" : "Menu";
  }

  toggle.addEventListener("click", function () {
    setOpen(toggle.getAttribute("aria-expanded") !== "true");
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && list.classList.contains("is-open")) {
      setOpen(false);
      toggle.focus();
    }
  });

  list.addEventListener("click", function (e) {
    if (e.target.closest("a")) setOpen(false);
  });

  document.addEventListener("click", function (e) {
    if (!list.contains(e.target) && !toggle.contains(e.target)) setOpen(false);
  });
})();

/* ---------- 2. Current page link and footer year ---------- */
(function () {
  let page = location.pathname.split("/").pop();
  if (!page) page = "index.html";
  const current = page.replace(/\.html$/, "");

  document.querySelectorAll(".nav-list a").forEach(function (link) {
    const href = (link.getAttribute("href") || "").split("#")[0];
    const target = (href || "index.html").replace(/\.html$/, "");
    if (target === current) link.setAttribute("aria-current", "page");
  });

  document.querySelectorAll("[data-year]").forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });
})();

/* ---------- 3. Forms ---------- */
(function () {
  const forms = document.querySelectorAll("form[data-form]");
  if (!forms.length) return;

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  // Accepts "example.com", "www.example.com" or "https://example.com"
  function looksLikeWebsite(value) {
    const v = value.trim();
    if (/\s/.test(v)) return false;
    return /^(https?:\/\/)?([a-z0-9-]+\.)+[a-z]{2,}(\/\S*)?$/i.test(v);
  }

  function fieldMessage(input) {
    const value = input.value.trim();
    const label = input.dataset.label || "This field";
    if (input.required && !value) {
      return input.tagName === "SELECT" ? "Choose an option for " + label.toLowerCase() + "." : label + " is required.";
    }
    if (value && input.type === "email" && !emailPattern.test(value)) {
      return "Enter a valid email address, for example name@company.com.";
    }
    if (value && input.dataset.type === "website" && !looksLikeWebsite(value)) {
      return "Enter a website address, for example www.example.com.";
    }
    if (value && input.minLength > 0 && value.length < input.minLength) {
      return label + " needs at least " + input.minLength + " characters.";
    }
    return "";
  }

  function showError(input, message) {
    const wrap = input.closest(".field");
    const box = wrap && wrap.querySelector(".field-error");
    if (!box) return;
    box.textContent = message;
    if (message) {
      input.setAttribute("aria-invalid", "true");
      input.setAttribute("aria-describedby", box.id);
    } else {
      input.removeAttribute("aria-invalid");
      input.removeAttribute("aria-describedby");
    }
  }

  function setStatus(form, kind, html) {
    const status = form.querySelector(".form-status");
    if (!status) return;
    status.className = "form-status is-" + kind;
    status.innerHTML = html;
  }

  function mailtoFallback(form) {
    const data = new FormData(form);
    const lines = [];
    data.forEach(function (value, key) {
      if (key.charAt(0) !== "_" && String(value).trim()) lines.push(key + ": " + value);
    });
    const subject = form.dataset.form === "audit" ? "Free marketing audit request" : "Website enquiry";
    return "mailto:" + GENERAL_EMAIL + "?subject=" + encodeURIComponent(subject) +
      "&body=" + encodeURIComponent(lines.join("\n"));
  }

  forms.forEach(function (form) {
    const fields = form.querySelectorAll("input:not([type=hidden]):not(.hp-input), select, textarea");

    fields.forEach(function (input) {
      input.addEventListener("blur", function () {
        if (input.value.trim() || input.dataset.touched) {
          input.dataset.touched = "1";
          showError(input, fieldMessage(input));
        }
      });
      input.addEventListener("input", function () {
        if (input.getAttribute("aria-invalid") === "true") showError(input, fieldMessage(input));
      });
    });

    form.addEventListener("submit", async function (e) {
      e.preventDefault();

      // Check every field and focus the first problem
      let firstBad = null;
      fields.forEach(function (input) {
        const msg = fieldMessage(input);
        showError(input, msg);
        if (msg && !firstBad) firstBad = input;
      });
      if (firstBad) {
        setStatus(form, "error", "Please fix the highlighted fields and try again.");
        firstBad.focus();
        return;
      }

      // Spam trap: real people never fill this hidden field
      const trap = form.querySelector(".hp-input");
      if (trap && trap.value) return;

      // Not connected yet: be honest, send nothing
      if (!FORM_ENDPOINT) {
        setStatus(
          form,
          "info",
          "This form is not connected yet, so nothing was sent. " +
          '<a href="' + mailtoFallback(form) + '">Email your details to us instead</a>.'
        );
        return;
      }

      // Connected: send and only report success if the service accepts it
      const button = form.querySelector("button[type=submit]");
      if (button) button.disabled = true;
      setStatus(form, "info", "Sending...");
      try {
        const response = await fetch(FORM_ENDPOINT, {
          method: "POST",
          body: new FormData(form),
          headers: { Accept: "application/json" }
        });
        if (response.ok) {
          form.reset();
          setStatus(form, "success", "Thank you. Your message has been sent. We will reply by email.");
        } else {
          throw new Error("Service answered with status " + response.status);
        }
      } catch (err) {
        setStatus(
          form,
          "error",
          'Your message could not be sent. Please try again, or <a href="' + mailtoFallback(form) + '">email us directly</a>.'
        );
      } finally {
        if (button) button.disabled = false;
      }
    });
  });
})();
